# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 19:06:56 2024

@author: rennc
"""

import pgzrun
import pygame
import pgzero
import random
import sys
from pgzero.builtins import Actor
from random import randint
import time

WIDTH = 800
HEIGHT = 600
CENTER_X = WIDTH / 2
CENTER_Y = HEIGHT / 2

move_list = []
display_list = []

score = 0
current_move = 0
count = 4
dance_length = 4
track = 1
say_dance = False
show_countdown = True
moves_complete = False
game_over = False
dancer = 1
dancer1 = Actor("dancer1-start")
dancer1.pos = CENTER_X - 50, CENTER_Y - 40
dancer2 = Actor("dancer2-start")
dancer2.pos = CENTER_X + 50, CENTER_Y - 40
up = Actor("up")
right = Actor("right")
down = Actor("down")
left = Actor("left")
up.pos = CENTER_X, CENTER_Y + 110
right.pos = CENTER_X + 60, CENTER_Y + 170
down.pos = CENTER_X, CENTER_Y + 230
left.pos = CENTER_X - 60, CENTER_Y + 170

y_button = Actor("y_button")
n_button = Actor("n_button")

y_button.pos = CENTER_X-60, CENTER_Y + 170
n_button.pos = CENTER_X+60, CENTER_Y + 170



def draw():
    global game_over, score, say_dance
    global count, show_countdown, track, dancer
    if not game_over:
        screen.clear()
        screen.blit("stage", (0,0))
        dancer1.draw()
        dancer2.draw()
        up.draw()
        down.draw()
        right.draw()
        left.draw()
        screen.draw.text("Score: " + str(score), color = "black", topleft = (10,10))
        
        if say_dance:
            screen.draw.text("Dance!", color="black", topleft = (CENTER_X - 65, 150), fontsize = 60)
        
        if show_countdown:
            screen.draw.text("Up next: Dancer " + str(dancer) + " in " + str(count), color="black", topleft=(CENTER_X-200, 150), fontsize = 60)
        
    else:
        screen.clear()
        screen.blit("stage", (0,0))
        screen.draw.text("Score: " + str(score),
                         color="black", topleft=(10,10))
        screen.draw.text("Game Over!",
                         color="black", topleft=(CENTER_X-130, 220), fontsize = 60)
        screen.draw.text("Retry?",
                         color="black", topleft=(CENTER_X, 280), fontsize = 30)
        match track:
            case 1:
                screen.draw.text("Song: Vanishing Horizons", color = "black", topleft = (10, 40), fontsize = 20)
            
            case 2:
                screen.draw.text("Song: Chiptune Adventures Stage 1", color = "black", topleft = (10, 40), fontsize = 20)
                screen.draw.text("Artist: Juhani Junkala", color = "black", topleft = (10, 70), fontsize = 20)
                
            case 3:
                screen.draw.text("Song: Chiptune Adventures Stage 2", color = "black", topleft = (10, 40), fontsize = 20)
                screen.draw.text("Artist: Juhani Junkala", color = "black", topleft = (10, 70), fontsize = 20)
                
            case 4:
                screen.draw.text("Song: Chiptune Adventures Boss Fight", color = "black", topleft = (10, 40), fontsize = 20)
                screen.draw.text("Artist: Juhani Junkala", color = "black", topleft = (10, 70), fontsize = 20)
        y_button.draw()
        n_button.draw()
        
    return

def reset_dancer1():
    global game_over
    if not game_over:
        dancer1.image = "dancer1-start"
        up.image = "up"
        right.image = "right"
        left.image = "left"
        down.image = "down"
    return
def reset_dancer2():
    global game_over
    if not game_over:
        dancer2.image = "dancer2-start"
        up.image = "up"
        right.image = "right"
        left.image = "left"
        down.image = "down"
    return
    
def update_dancer1(move):
    global game_over
    if not game_over:
        if move == 0:
            up.image = "up-lit"
            dancer1.image = "dancer1-up"
            clock.schedule(reset_dancer1,0.5)
        elif move == 1:
            right.image = "right-lit"
            dancer1.image = "dancer1-right"
            clock.schedule(reset_dancer1,0.5)
        elif move == 2:
            down.image = "down-lit"
            dancer1.image = "dancer1-down"
            clock.schedule(reset_dancer1,0.5)
        else:
            left.image = "left-lit"
            dancer1.image = "dancer1-left"
            clock.schedule(reset_dancer1,0.5)
    return

def update_dancer2(move):
    global game_over
    if not game_over:
        if move == 0:
            up.image = "up-lit"
            dancer2.image = "dancer2-up"
            clock.schedule(reset_dancer2,0.5)
        elif move == 1:
            right.image = "right-lit"
            dancer2.image = "dancer2-right"
            clock.schedule(reset_dancer2,0.5)
        elif move == 2:
            down.image = "down-lit"
            dancer2.image = "dancer2-down"
            clock.schedule(reset_dancer2,0.5)
        else:
            left.image = "left-lit"
            dancer2.image = "dancer2-left"
            clock.schedule(reset_dancer2,0.5)
    return


def display_moves():
    global move_list, display_list, dance_length
    global say_dance, show_countdown, current_move, dancer
    if display_list:
        this_move = display_list[0]
        display_list = display_list[1:]
        if this_move == 0:
            if dancer == 1:
                update_dancer1(0)
            elif dancer == 2:
                update_dancer2(0)
            clock.schedule(display_moves, 1)
        elif this_move == 1:
            if dancer == 1:
                update_dancer1(1)
            elif dancer == 2:
                update_dancer2(1)
            clock.schedule(display_moves, 1)
        elif this_move == 2:
            if dancer == 1:
                update_dancer1(2)
            elif dancer == 2:
                update_dancer2(2)
            clock.schedule(display_moves, 1)
        else:
            if dancer == 1:
                update_dancer1(3)
            elif dancer == 2:
                update_dancer2(3)
            clock.schedule(display_moves, 1)
    else:
        say_dance = True
        show_countdown = False
    return

    

def generate_moves():
    global move_list, dance_length, count, show_countdown, say_dance, dancer
    count = 4
    move_list = []
    say_dance = False
    for move in range(0, dance_length):
        rand_move = randint(0,3)
        move_list.append(rand_move)
        display_list.append(rand_move)
    show_countdown = True
    if dancer == 2:
        dancer = 1
    elif dancer == 1:
        dancer = 2
    countdown()
    return

def countdown():
    global count, game_over, show_countdown
    if count > 1:
        count = count - 1
        clock.schedule(countdown, 1)
    else:
        show_countdown = False
        display_moves()
    return

def next_move():
    global dance_length, current_move, moves_complete
    if current_move <dance_length - 1:
        current_move = current_move + 1
    else:
        moves_complete = True
    return


def on_key_up(key):
    global score, game_over, move_list, current_move, dancer
    if dancer == 1:
        if key == keys.UP:
            update_dancer1(0)
            if move_list[current_move] ==0:
                score = score + 1
                next_move()
            else:
                game_over = True
        elif key == keys.RIGHT:
            update_dancer1(1)
            if move_list[current_move] ==1:
                score = score + 1
                next_move()
            else:
                game_over = True
        elif key == keys.DOWN:
            update_dancer1(2)
            if move_list[current_move] ==2:
                score = score + 1
                next_move()
            else:
                game_over = True
        elif key == keys.LEFT:
            update_dancer1(3)
            if move_list[current_move] ==3:
                score = score + 1
                next_move()
            else:
                game_over = True
    elif dancer == 2:
        if key == keys.W:
            update_dancer2(0)
            if move_list[current_move] ==0:
                score = score + 1
                next_move()
            else:
                game_over = True
        elif key == keys.D:
            update_dancer2(1)
            if move_list[current_move] ==1:
                score = score + 1
                next_move()
            else:
                game_over = True
        elif key == keys.S:
            update_dancer2(2)
            if move_list[current_move] ==2:
                score = score + 1
                next_move()
            else:
                game_over = True
        elif key == keys.A:
            update_dancer2(3)
            if move_list[current_move] ==3:
                score = score + 1
                next_move()
            else:
                game_over = True
    return

def on_mouse_down(pos):
    if y_button.collidepoint(pos):
        start_game()
    elif n_button.collidepoint(pos):
        endprogram()
        
def start_game():
    global say_dance, show_countdown, moves_complete, game_over
    global score, move_list, display_list, current_move, dance_length, track
    move_list = []
    display_list = []
    dancer = 1
    score = 0
    current_move = 0
    count = 4
    dance_length = 4
    say_dance = False
    show_countdown = True
    moves_complete = False
    game_over = False
    
    reset_dancer1()
    reset_dancer2()
    generate_moves()
    music_rotation()
    
def music_rotation():
    global track
    track = randint(1,4)
    if track == 1:
        music.play("vanishing-horizon") 
    elif track == 2:
        music.play("juhani junkala [chiptune adventures] 1. stage 1")
    elif track == 3:
        music.play("juhani junkala [chiptune adventures] 2. stage 2")
    elif track == 4:
        music.play("juhani junkala [chiptune adventures] 3. boss fight")
def update():
    global game_over, current_move, moves_complete
    if not game_over:
        if moves_complete:
            generate_moves()
            moves_complete = False
            current_move = 0
    else:
        music.stop()
def endprogram():
    pygame.quit()
    sys.exit()
start_game()

pgzrun.go()
